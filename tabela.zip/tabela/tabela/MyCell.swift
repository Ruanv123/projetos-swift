//
//  MyCell.swift
//  tabela
//
//  Created by COTEMIG on 28/03/23.
//

import UIKit

class MyCell: UITableViewCell {
    
    @IBOutlet weak var LabelName: UILabel!
    @IBOutlet weak var LabelTel: UILabel!
    @IBOutlet weak var LabelMail: UILabel!
    @IBOutlet weak var LabelCity: UILabel!
}
    
