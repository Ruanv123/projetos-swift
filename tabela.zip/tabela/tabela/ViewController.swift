//
//  ViewController.swift
//  tabela
//
//  Created by COTEMIG on 28/03/23
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource {
    
    var listaContato: [Contato] = []
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        listaContato.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let contato = listaContato[indexPath.row]
        
        if let cell = tableView .dequeueReusableCell(withIdentifier: "mycell", for: indexPath) as? MyCell {
            cell.LabelName.text = contato.nome
            cell.LabelCity.text = contato.cidade
            cell.LabelMail.text = contato.email
            cell.LabelTel.text = contato.telefone
            return cell
        }
        return UITableViewCell()
    }
    
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        tableView.delegate = self
        
        listaContato.append(Contato(nome: "Ruan Victor", telefone: "31-98644-1470", email: "teste@teste.com", cidade: "Belo horizonte"))
        
        tableView.reloadData()
        // Do any additional setup after loading the view.
    }
}

extension ViewController: UITableViewDelegate{
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let contato = listaContato[indexPath.row]
        print("clicou na celula \(indexPath.row)")
        print("cliquei no contato \(contato)")
    }
}

struct Contato {
    var nome: String
    var telefone: String
    var email: String
    var cidade: String
}


