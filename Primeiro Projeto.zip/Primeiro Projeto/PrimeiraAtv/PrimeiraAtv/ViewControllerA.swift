//
//  ViewControllerA.swift
//  PrimeiraAtv
//
//  Created by COTEMIG on 14/03/23.
//

import UIKit

class ViewControllerA:UIViewController {
    
    var nome: String?
    
    @IBOutlet weak var labelTela2: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        labelTela2.text = nome

        // Do any additional setup after loading the view.
    }
    @IBAction func deBpraC(_ sender: Any) {
        performSegue(withIdentifier: "irpraC", sender: nome)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let vc2 = segue.destination as? ViewControllerB,
           let txt = sender as? String{
            vc2.nome = txt
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
