//
//  ViewController.swift
//  PrimeiraAtv
//
//  Created by COTEMIG on 14/03/23.
//

import UIKit

class ViewController: UIViewController {
    var valor = ""
    
    @IBOutlet weak var textValue: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    

    @IBAction func irparaB(_ sender: Any) {
        valor = textValue.text!
        performSegue(withIdentifier: "TelaA", sender: valor)
    }
    @IBAction func buttonTap(_ sender: Any) {
        valor = textValue.text!
        performSegue(withIdentifier: "TelaA", sender: valor)    }
    
    
    @IBAction func irParaTela3(_ sender: Any) {
        valor = textValue.text!
        performSegue(withIdentifier: "Tela3", sender: valor)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if let vc = segue.destination as? ViewControllerA,
           let txt = sender as? String{
            vc.nome = txt
        }
        
        if let vc2 = segue.destination as? ViewControllerB,
           let txt2 = sender as? String{
            vc2.nome = txt2
        }
        
    }
    
    

}

