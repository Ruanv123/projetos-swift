//
//  ViewController.swift
//  primeiro-projeto
//
//  Created by COTEMIG on 28/02/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

