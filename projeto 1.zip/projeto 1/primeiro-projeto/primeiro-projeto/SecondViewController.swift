//
//  SecondViewController.swift
//  primeiro-projeto
//
//  Created by COTEMIG on 28/02/23.
//

import UIKit

class SecondViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
       
        // Do any additional setup after loading the view.
    }
    
    @IBOutlet weak var label: UILabel!
    @IBAction func button(_ sender: Any) {
        
    }
    
    @IBOutlet weak var outlet_textField: UITextField!
    @IBOutlet weak var outlet_Btn: UIButton!
    @IBAction func butontap(_ sender: Any) {
        
        	performSegue(withIdentifier: "mudarTela", sender:   nil)
    }
    
    @IBAction func butonTapCor(_ sender: Any) {
        view.backgroundColor = .darkGray
    }
    @IBAction func brtCor2(_ sender: Any) {
        view.backgroundColor = .systemGreen
    }
    @IBAction func slider(_ sender: Any) {
        if sla.isOn
        {
            view.backgroundColor = .darkGray
            
        } else
        {
            view.backgroundColor = .white
        }
        
    }
    @IBOutlet weak var sla: UISwitch!
    
    @IBAction func telaReg(_ sender: Any) {
        performSegue(withIdentifier: "irParaReg", sender: nil)
    }
    
    @IBAction func ajudalembra(_ sender: Any) {
        performSegue(withIdentifier: "irParaReg", sender: nil)
    	}
    
    // MARK: - Navigation
    
    /*
    
     	

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
